from flask import Flask, render_template, request
import joblib
import numpy as np

app = Flask(__name__)

pipeline = joblib.load("breast_cancer_pipeline.pkl")

models = pipeline["models"]
feature_names = pipeline["feature_names"]
imputer = pipeline["imputer"]

@app.route("/")
def home():
    return render_template("index.html", feature_names=feature_names)

@app.route("/predict", methods=["POST"])
def predict():

    values = []

    for feature in feature_names:
        value = request.form.get(feature)

        if value == "":
            values.append(np.nan)
        else:
            values.append(float(value))

    data = np.array(values).reshape(1, -1)

    data = imputer.transform(data)

    predictions = {}

    for name, model in models.items():
        pred = model.predict(data)[0]
        result = "Malignant (Cancer)" if pred == 1 else "Benign"
        predictions[name] = result

    return render_template(
        "index.html",
        feature_names=feature_names,
        predictions=predictions
    )

if __name__ == "__main__":
    app.run(debug=True)