import streamlit as st
import joblib
import pandas as pd

model = joblib.load("model.job")
scalers = joblib.load("scalers")
encoders = joblib.load("encoders")

st.header("Titanic Survival Prediction")


sex = st.selectbox("Sex", ["male", "female"])
age = st.slider("Age",.1,100.0,.01)

sibsp = st.slider("Sibsp",1,10,1)

parch = st.slider("Parch",1,10,1)

fare = st.slider("Fare",.1,100.0,.01)
clas = st.selectbox("Class", ["First", "Second", "Third"])
who = st.selectbox("Who", ["man", "woman", "child"])
adult_male = st.selectbox("Adult Male", [True, False])
embark_town = st.selectbox("Embark Town", ["Southampton", "Cherbourg", "Queenstown"])
alone = st.selectbox("Alone", [True, False])


data = pd.DataFrame([{"sex": sex,"age": age,"sibsp": sibsp,"parch": parch,"fare": fare,"class": clas,
"who": who,"adult_male": adult_male,"embark_town": embark_town,"alone": alone}])


new_data = data.copy()

for col in new_data.columns:
    if col in scalers: 
        new_data[col] = scalers[col].transform(new_data[[col]])
    elif col in encoders:
        new_data[col] = encoders[col].transform(new_data[[col]])


if st.button("Submit Data"):
    pred = model.predict(new_data)

    if pred == 1:
        st.success("Passenger Survived!")
    else:
        st.error("Passenger Dead!")
 