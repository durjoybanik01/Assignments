from flask import Flask, request, jsonify, render_template
import joblib
import re
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer

app = Flask(__name__)

model = joblib.load("model.pkl")
vectorizer = joblib.load("vectorizer.pkl")

stop_word = stopwords.words("english")
lemmatizer = WordNetLemmatizer()

def preprocess(text):
    text = text.lower()
    text = re.sub(r"[^\w\s]", "", text)
    text = re.sub(r"\d+", "", text)
    text = text.split()
    text = [lemmatizer.lemmatize(word) for word in text if word not in stop_word]
    return " ".join(text)

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/predict", methods=["POST"])
def predict():
    text = request.form.get("text")

    cleaned = preprocess(text)
    vector = vectorizer.transform([cleaned])
    prediction = model.predict(vector)[0]

    return render_template("index.html",prediction=prediction,input_text=text)

@app.route("/api/predict", methods=["POST"])
def api_predict():
    data = request.get_json()

    cleaned = preprocess(data["text"])
    vector = vectorizer.transform([cleaned])
    prediction = model.predict(vector)[0]

    return jsonify({
        "input": data["text"],
        "prediction": prediction
    })

if __name__ == "__main__":
    app.run(debug=True)